package com.example.numberpickerdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.Toast;

public class Main extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		// Create the array of numbers that will populate the numberpicker
		final String[] nums = new String[21];
		for(int i=0; i<nums.length; i++) {
		   nums[i] = Integer.toString(i*5);
		}
		
		// Set the max and min values of the numberpicker, and give it the
		// array of numbers created above to be the displayed numbers
		final NumberPicker np = (NumberPicker) findViewById(R.id.np);
		np.setMaxValue(20);
		np.setMinValue(0);
		np.setWrapSelectorWheel(false);
		np.setDisplayedValues(nums);
		
		Button button = (Button) findViewById(R.id.button);
		button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// Show the selected value of the numberpicker when the button is clicked
				Toast.makeText(Main.this, "Selected value: " + nums[np.getValue()], Toast.LENGTH_SHORT).show();
			}
		});
	}
}
